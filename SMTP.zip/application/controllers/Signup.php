<?php
  class Signup extends CI_Controller
  {

    public function __construct()
    {
      parent:: __construct();
      $this->load->library('form_validation');
      $this->load->model('Registration');
      //$this->load->library('encrypt');
    }

    public function index()
    {
      $this->load->view('signup');

    }

    function form_validation()
    {
      $this->form_validation->set_rules('name',"Name","required");
      $this->form_validation->set_rules('email',"Email","required|valid_email");
      $this->form_validation->set_rules('password',"Password","required");
      if($this->form_validation->run()){
        $key=md5(rand());
        $encryptPassword=md5($this->input->post('password'));

        $data =array(
          'name'=>$this->input->post('name'),
          'email'=>$this->input->post('email'),
          'password'=>$encryptPassword,
          'key'=>$key
        );

        if($this->Registration->insert_data($data)) {
          $sub="Kindly verfiy your email";
          $info='
          <h3>Hello, '.$this->input->post('name').'</h3>
          <a href="'.base_url('Signup/verify_email'.$key).'">Click here</a>
          ';
         $config=array();

          //$config['useragent'] = 'CodeIgniter';
        $config['protocol'] = 'smtp';
        //$config['mailpath'] = '/usr/sbin/sendmail';
        $config['smtp_host'] = 'ssl://smtp.googlemail.com';
        $config['smtp_user'] = 'Your Gmail';
        $config['smtp_pass'] = 'Your Mail Password';
        $config['smtp_port'] = 465;
        //$config['smtp_timeout'] = 5;
        //$config['wordwrap'] = TRUE;
        $config['mailtype'] = 'html';
        $config['charset'] = 'utf-8';
        //$config['validate'] = FALSE;
        $config['newline'] = "\r\n";

          $this->load->library('email');
          $this->email->initialize($config);



          $this->email->from('vamsikrishnakdml@gmail.com');
          $this->email->to($this->input->post('email'));
          $this->email->subject($sub);
          $this->email->message($info);

          if ($this->email->send())
          echo $info;
          else {
            echo "noo";
          }
        }else {
          echo "FAILED";
        }



      }
    }

  }


 ?>
