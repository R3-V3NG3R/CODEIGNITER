<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>:: Signup Form ::</title>


    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>">

  </head>
  <body class="container">
    <div class="col-md-6 offset-3">
      <div class="card">
        <div class="card-header">
          <h2>Sign Up</h2>
        </div>
        <div class="card-body">
          <form class="" action="<?php echo base_url('Signup/form_validation'); ?>" method="post">
            <input type="text" name="name" value="" placeholder="Name" class="form-control" >
            <span class="text-danger"><?php echo form_error('name'); ?></span><br>
            <input type="email" name="email" value="" placeholder="Email" class="form-control" >
            <span class="text-danger"><?php echo form_error('email'); ?></span><br>
            <input type="password" name="password" value="" placeholder="password" class="form-control">
            <span class="text-danger"><?php echo form_error('password'); ?></span><br>
            <button type="submit" name="signup" class="btn btn-primary btn-block">Submit</button>
          </form>
        </div>
      </div>
    </div>

    <script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>" charset="utf-8"></script>
  </body>
</html>
