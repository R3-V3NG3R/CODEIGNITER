<?php

  /**
   *
   */
  class Registration extends CI_Model
  {

    public function insert_data ($data)
    {
      $this->db->insert('users',$data);
      return $this->db->insert_id();
    }

  }



 ?>
